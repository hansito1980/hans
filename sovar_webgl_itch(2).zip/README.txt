SOVAR v4.4.0-Nihil // Edición WebGL Itch.io
=============================================

ESTRUCTURA DEL PAQUETE:
- index.html -> Aplicación WebGL completa autocontenida con interfaz Terminal Matrix verde fosforescente, pasarela de wallet descentralizada y simulación en tiempo real de los 290 nodos de enjambre.
- Wallet Integrada: bc1q5sth6ualcqd00pwkmv5glr384vjtd5t4h7nkkp

INSTRUCCIONES DE SUBIDA A ITCH.IO:
1. Comprime o sube directamente el archivo 'index.html' (o este ZIP completo).
2. En la configuración de subida de Itch.io, selecciona el tipo de proyecto como "HTML5".
3. Marca la opción "This file will be played in the browser".
4. Dimensiones recomendadas de vista previa: 1280x720 o adaptable.
